"""return data safe to process, uci contains corrupted row for the dataset

call function init to get raw, well-defined complete dataset.

the code using this module to import the data should have the following structure

- project_folder
    - data
        - __init__.py
        - algerian_forest_fires.py
        - Bejaia Region Dataset.csv
        - Sidi-Bel Abbes Region Dataset.csv
    - part_A
        - your_code.py

and in `your_code`.py, import the module using the example code follow:

```python

# appending a path
sys.path.append(os.path.join(Path(__file__).resolve().parent.parent,'algerian_forest_fires'))
# import package
from algerian_forest_fires import algerian_forest_fires

df=algerian_forest_fires().df
```
"""

import os
from pathlib import Path
import pandas as pd
from datetime import datetime


class algerian_forest_fires:
    
    def __load_datetime(self,row,as_timestamp=True):
        """ return row year, month, date as datetime value, return timestamp on default.
        """
        date = datetime(day=row['day'], month=row['month'], year=row['year'])
        return datetime.timestamp(date) if as_timestamp else date
    
    def __init__(self):
        # load local data
        b_df = pd.read_csv(
            os.path.join(Path(__file__).resolve().parent, "Bejaia Region Dataset.csv")
        )
        s_df = pd.read_csv(
            os.path.join(
                Path(__file__).resolve().parent, "Sidi-Bel Abbes Region Dataset.csv"
            )
        )
        b_df["region"] = "Bejaia"
        s_df["region"] = "Sidi-Bel Abbes"
        col_types = {
            "region": str,
            "day": int,
            "month": int,
            "year": int,
            "Temperature": int,
            "RH": int,
            "Ws": int,
            "Rain": float,
            "FFMC": float,
            "DMC": float,
            "DC": float,
            "ISI": float,
            "BUI": float,
            "FWI": float,
            "Classes": str,
        }
        numerical_vals = [
            "day",
            "month",
            "year",
            "Temperature",
            "RH",
            "Ws",
            "Rain",
            "FFMC",
            "DMC",
            "DC",
            "ISI",
            "BUI",
            "FWI",
        ]
        categorical_vals = ["region", "Classes"]
        self.df = pd.concat([b_df, s_df]).astype(col_types)
        self.numerical = numerical_vals
        self.categorical = categorical_vals
        self.col_names = col_types.keys()
        self.col_types = col_types
        self.b_df = b_df.astype(col_types)
        self.s_df = s_df.astype(col_types)
        self.init_date=min([self.__load_datetime(row,as_timestamp=False) for _,row in self.df.iterrows()])

    def data(self):
        """ return packed dictionary of data

        Returns:
            "data": self.df,
            "numerical": self.numerical,
            "categorical": self.categorical,

        """
        return {
            "data": self.df,
            "numerical": self.numerical,
            "categorical": self.categorical,
        }
    
    
    def __load_scale_date(self,row):
        date = datetime(day=row['day'], month=row['month'], year=row['year'])
        delta=date-self.init_date
        return delta.days

    def merge_time_data(self,scale=False):
        merge_df = self.df.copy()
        if scale:
            merge_df ["Day"] = merge_df.apply(self.__load_scale_date, axis=1)
        else:
            merge_df ["timestamp"] = merge_df.apply(self.__load_datetime, axis=1)
        merge_df = merge_df.drop(["day", "month", "year"], axis=1)
        return {
            "data": merge_df,
            "numerical": [
                "Day" if scale else "timestamp",
                "Temperature",
                "RH",
                "Ws",
                "Rain",
                "FFMC",
                "DMC",
                "DC",
                "ISI",
                "BUI",
                "FWI",
            ],
            "categorical": self.categorical,
        }
